/*
 * Helper do Stripe — REST API via fetch (sem SDK, sem dependências).
 *
 * Gateway de pagamentos (substitui a WayMB). Métodos: MB WAY e Multibanco.
 * Fluxo transparente (server-side, sem Stripe.js):
 *   - MB WAY:     PaymentIntent com payment_method_data.mb_way.phone + confirm
 *   - Multibanco: PaymentIntent multibanco → next_action com voucher (entity/ref)
 *
 * Env: STRIPE_SECRET_KEY.
 */

const SK = process.env.STRIPE_SECRET_KEY || '';
const API = 'https://api.stripe.com/v1';
const RETURN_URL = 'https://www.applecardpt.com/obrigado.html';

// Serializa objeto (aninhado) no form-encoded que o Stripe espera (bracket notation).
function encode(obj, prefix) {
  const parts = [];
  for (const key in obj) {
    const val = obj[key];
    if (val === undefined || val === null) continue;
    const k = prefix ? prefix + '[' + key + ']' : key;
    if (typeof val === 'object' && !Array.isArray(val)) {
      const nested = encode(val, k);
      if (nested) parts.push(nested);
    } else {
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(val));
    }
  }
  return parts.join('&');
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(id); }
}

async function stripe(path, method, body) {
  if (!SK) return { ok: false, status: 0, data: { error: { message: 'STRIPE_SECRET_KEY ausente' } } };
  const opt = {
    method,
    headers: {
      Authorization: 'Bearer ' + SK,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  };
  if (body) opt.body = encode(body);
  const r = await fetchWithTimeout(API + path, opt, 15000);
  const j = await r.json().catch(() => null);
  return { ok: r.ok, status: r.status, data: j };
}

// Cria e confirma um pagamento MB WAY (push para o app do cliente).
function createMbway({ amount, phone, name, email, metadata }) {
  return stripe('/payment_intents', 'POST', {
    amount,               // em cêntimos
    currency: 'eur',
    confirm: true,
    return_url: RETURN_URL,
    payment_method_data: {
      type: 'mb_way',
      billing_details: { name: name || undefined, email: email || undefined, phone },
    },
    metadata: metadata || {},
  });
}

// Cria e confirma um pagamento Multibanco (voucher entity/reference).
function createMultibanco({ amount, name, email, metadata }) {
  return stripe('/payment_intents', 'POST', {
    amount,
    currency: 'eur',
    confirm: true,
    return_url: RETURN_URL,
    payment_method_data: {
      type: 'multibanco',
      billing_details: { name: name || undefined, email: email || undefined },
    },
    metadata: metadata || {},
  });
}

function getPaymentIntent(id) {
  return stripe('/payment_intents/' + encodeURIComponent(id), 'GET');
}

// Normaliza o status do PaymentIntent para PENDING | APPROVED | REFUSED.
function normalizeStatus(piStatus) {
  if (piStatus === 'succeeded') return 'APPROVED';
  if (piStatus === 'canceled' || piStatus === 'requires_payment_method') return 'REFUSED';
  return 'PENDING'; // requires_action, processing, requires_confirmation
}

module.exports = { createMbway, createMultibanco, getPaymentIntent, normalizeStatus, encode };
