/*
 * Webhook do Stripe — POST /api/stripe-webhook
 *
 * Confirmação confiável de pagamento. Ao receber payment_intent.succeeded:
 * grava a venda no Supabase e dispara o Purchase server-side (TikTok + Meta),
 * deduplicado por PaymentIntent id. Verifica a assinatura (STRIPE_WEBHOOK_SECRET).
 */

const crypto = require('crypto');
const store = require('./_store');
const tt = require('./tt');
const fb = require('./fb');

const WH_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';

const fired = new Map();
function alreadyFired(id) {
  const now = Date.now();
  for (const [k, t] of fired) if (now - t > 60 * 60 * 1000) fired.delete(k);
  return fired.has(id);
}
function markFired(id) { fired.set(id, Date.now()); }

function readRaw(req) {
  return new Promise((resolve) => {
    let data = '';
    try {
      req.on('data', (c) => { data += c; });
      req.on('end', () => resolve(data));
      req.on('error', () => resolve(data));
      setTimeout(() => resolve(data), 5000);
    } catch { resolve(''); }
  });
}

// Verifica a assinatura do Stripe (t=...,v1=...) via HMAC-SHA256.
function verifySignature(raw, sigHeader, secret) {
  let t = '';
  const v1 = [];
  String(sigHeader || '').split(',').forEach((p) => {
    const [k, v] = p.split('=');
    if (k === 't') t = v;
    if (k === 'v1') v1.push(v);
  });
  if (!t || !v1.length) return false;
  const expected = crypto.createHmac('sha256', secret).update(t + '.' + raw).digest('hex');
  const expBuf = Buffer.from(expected);
  return v1.some((v) => {
    try {
      const vBuf = Buffer.from(v);
      return vBuf.length === expBuf.length && crypto.timingSafeEqual(vBuf, expBuf);
    } catch { return false; }
  });
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'method not allowed' });
  }

  const raw = await readRaw(req);
  const sig = req.headers['stripe-signature'] || '';
  if (WH_SECRET) {
    if (!verifySignature(raw, sig, WH_SECRET)) {
      console.error('[stripe-webhook] assinatura inválida');
      return res.status(400).json({ error: 'invalid signature' });
    }
  }

  let event;
  try { event = JSON.parse(raw); } catch { return res.status(400).json({ error: 'invalid json' }); }

  try {
    if (event.type === 'payment_intent.succeeded') {
      const pi = event.data.object;
      if (pi && pi.id && !alreadyFired(pi.id)) {
        markFired(pi.id);
        const meta = pi.metadata || {};
        const value = (typeof pi.amount === 'number' ? pi.amount : 0) / 100;

        try {
          await store.recordSale({
            transactionId: pi.id,
            conta: 'stripe',
            value,
            currency: 'EUR',
            method: pi.payment_method_types && pi.payment_method_types[0],
            payer_name: meta.payer_name || '',
            payer_email: meta.payer_email || '',
            payer_document: meta.document || '',
            paidAt: new Date().toISOString(),
            source: 'stripe-webhook',
          });
        } catch (e) { console.error('[stripe-webhook:venda]', e && e.message); }

        const purchaseEvent = {
          event: 'Purchase',
          eventId: 'purchase_' + pi.id,
          properties: {
            currency: 'EUR', value, content_type: 'product',
            content_id: 'apple-card-pt', content_name: 'Apple Card', transaction_id: pi.id,
          },
          user: { external_id: meta.document || pi.id, email: meta.payer_email, phone: meta.phone },
          page: { url: 'https://www.applecardpt.com/' },
        };
        await Promise.allSettled([
          tt.sendServerEvent(purchaseEvent).catch((e) => console.error('[stripe-webhook:tt]', e && e.message)),
          fb.sendServerEvent(purchaseEvent).catch((e) => console.error('[stripe-webhook:fb]', e && e.message)),
        ]);
        console.log('[stripe-webhook] Purchase conta=' + (meta.conta || '?') + ' valor=' + value + ' pi=' + pi.id);
      }
    }
  } catch (e) {
    console.error('[stripe-webhook] exceção', e && e.message);
  }

  return res.status(200).json({ received: true });
};

module.exports.config = { api: { bodyParser: false } };
