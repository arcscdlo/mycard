/*
 * Meta (Facebook) Conversions API — server-side.
 *
 * Espelha o Meta Pixel (fbq) client-side do tracker.js: reenvia os mesmos
 * eventos via Graph API, deduplicados por event_id, para melhorar match
 * quality. Mesma arquitetura do tt.js (TikTok Events API).
 *
 *   - pixel id:        process.env.FB_PIXEL_ID (1698181571306790)
 *   - access token:    process.env.FB_ACCESS_TOKEN (configurado em Vercel)
 *   - dedup:           via event_id (igual ao client-side fbq eventID)
 *   - test events:     process.env.FB_TEST_EVENT_CODE (opcional, p/ Events Manager)
 *
 * É também invocado por /api/webhook e /api/status quando o WayMB confirma o
 * pagamento (Purchase server-side de confiança, com transactionId no event_id).
 */

const crypto = require('crypto');

const TEST_EVENT_CODE = process.env.FB_TEST_EVENT_CODE || '';
const API_VERSION = 'v21.0';

// Lista de pixels Meta — cada um {id, token}. Suporta múltiplos pixels/CAPI:
//   - FB_PIXELS: JSON, ex. [{"id":"123","token":"EAA..."},{"id":"456","token":"EAA..."}]
//   - ou o par único FB_PIXEL_ID + FB_ACCESS_TOKEN (retrocompat).
// Cada pixel recebe TODOS os eventos (mesmo event_id → dedup com o client-side).
function loadPixels() {
  const raw = process.env.FB_PIXELS;
  if (raw) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        const list = arr
          .filter((p) => p && p.id && p.token)
          .map((p) => ({ id: String(p.id), token: String(p.token) }));
        if (list.length) return list;
      }
    } catch (e) {
      console.error('[fb] FB_PIXELS inválido (esperado JSON array):', e && e.message);
    }
  }
  return [{
    id: process.env.FB_PIXEL_ID || '1698181571306790',
    token: process.env.FB_ACCESS_TOKEN || ''
  }];
}

const PIXELS = loadPixels();

function sha256(s) {
  return crypto.createHash('sha256')
    .update(String(s == null ? '' : s).trim().toLowerCase())
    .digest('hex');
}

function digitsOnly(s) { return String(s || '').replace(/\D+/g, ''); }

// Meta quer telemóvel só com dígitos + código de país (sem '+'). PT: 351 + 9.
function normalizePhone(raw) {
  if (!raw) return '';
  var d = digitsOnly(raw);
  if (d.startsWith('351') && d.length === 12) return d;
  if (d.length === 9) return '351' + d;
  return d;
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(id); }
}

// Envia o evento a um pixel específico (id + token).
async function sendToOnePixel(pixel, data) {
  if (!pixel.token) {
    console.error('[fb] token ausente para o pixel', pixel.id);
    return { ok: false, reason: 'no_token', pixel: pixel.id };
  }
  try {
    const payload = { data, access_token: pixel.token };
    if (TEST_EVENT_CODE) payload.test_event_code = TEST_EVENT_CODE;
    const url = `https://graph.facebook.com/${API_VERSION}/${pixel.id}/events`;
    const r = await fetchWithTimeout(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }, 8000);
    const json = await r.json().catch(() => ({}));
    if (!r.ok || (json && json.error)) {
      console.error('[fb] CAPI erro pixel=' + pixel.id, r.status, JSON.stringify(json).slice(0, 500));
      return { ok: false, status: r.status, response: json, pixel: pixel.id };
    }
    return { ok: true, response: json, pixel: pixel.id };
  } catch (e) {
    console.error('[fb] CAPI exception pixel=' + pixel.id, e && e.message);
    return { ok: false, reason: 'exception', pixel: pixel.id };
  }
}

// Faz fan-out do evento para todos os pixels configurados.
async function sendEventToMeta(data) {
  const results = await Promise.all(PIXELS.map((p) => sendToOnePixel(p, data)));
  return { ok: results.every((r) => r.ok), results };
}

function buildUserData({ user, ip, userAgent, fbc, fbp }) {
  user = user || {};
  const ud = {};
  if (user.email) ud.em = [sha256(user.email)];
  const phone = normalizePhone(user.phone);
  if (phone) ud.ph = [sha256(phone)];
  if (user.external_id) ud.external_id = [sha256(user.external_id)];
  if (ip) ud.client_ip_address = ip;
  if (userAgent) ud.client_user_agent = userAgent;
  if (fbc) ud.fbc = fbc;
  if (fbp) ud.fbp = fbp;
  return ud;
}

// Converte as properties (taxonomia TikTok) para custom_data do Meta.
function buildCustomData(properties) {
  properties = (properties && typeof properties === 'object' && !Array.isArray(properties)) ? properties : {};
  const cd = {};
  Object.keys(properties).forEach((k) => {
    if (k === 'event_id') return; // event_id vai no nível do evento
    cd[k] = properties[k];
  });
  // Meta também é sensível a value não-numérico — coage para número.
  if ('value' in cd) {
    const v = parseFloat(cd.value);
    cd.value = Number.isFinite(v) ? v : 0;
  }
  if (!('currency' in cd)) cd.currency = 'EUR';
  // content_id (singular, TikTok) -> content_ids (array, Meta)
  if (cd.content_id && !cd.content_ids) cd.content_ids = [cd.content_id];
  return cd;
}

/**
 * Helper público para outros endpoints (api/webhook, api/status) chamarem sem
 * HTTP round-trip.
 *
 *   await sendServerEvent({ event, eventId, properties, user, page, ip, userAgent, fbc, fbp })
 */
async function sendServerEvent({ event, eventId, properties, user, page, ip, userAgent, fbc, fbp }) {
  if (!event) return { ok: false, reason: 'no_event' };
  page = page || {};
  const evt = {
    event_name: event,
    event_time: Math.floor(Date.now() / 1000),
    event_id: eventId || ('srv_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)),
    action_source: 'website',
    user_data: buildUserData({ user, ip, userAgent, fbc, fbp })
  };
  if (page.url) evt.event_source_url = page.url;
  const cd = buildCustomData(properties);
  if (Object.keys(cd).length) evt.custom_data = cd;
  return sendEventToMeta([evt]);
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    res.status(204).end();
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = null; }
  }
  if (!body || typeof body !== 'object') { res.status(204).end(); return; }

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
          || req.socket?.remoteAddress || '';
  const ua = req.headers['user-agent'] || '';

  const result = await sendServerEvent({
    event: body.event,
    eventId: body.event_id,
    properties: body.params,
    user: body.user || {},
    page: body.page || {},
    ip,
    userAgent: ua,
    fbc: body.fbc || '',
    fbp: body.fbp || ''
  });

  // Resposta minimal — sendBeacon não lê o body, é fire-and-forget.
  res.status(200).json({ ok: result.ok });
};

// Exporta o helper pra ser usado por outros endpoints.
module.exports.sendServerEvent = sendServerEvent;
