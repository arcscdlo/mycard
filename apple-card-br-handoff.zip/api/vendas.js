/*
 * Relatório de vendas — GET /api/vendas?token=<VENDAS_TOKEN>
 *
 * Devolve nº de vendas e receita por conta WayMB (default vs google/b2) + as
 * últimas vendas com origem. Protegido por token (env VENDAS_TOKEN).
 * Requer o Vercel KV provisionado (ver api/_store.js).
 */

const store = require('./_store');

module.exports = async function handler(req, res) {
  const token = (req.query && (req.query.token || req.query.t))
             || req.headers['x-vendas-token'] || '';
  const expected = process.env.VENDAS_TOKEN || '';
  if (!expected || token !== expected) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  res.setHeader('Cache-Control', 'no-store');

  const report = await store.getReport(50);
  if (!report.enabled) {
    return res.status(200).json({
      enabled: false,
      hint: 'Provisione o Vercel KV (KV_REST_API_URL/KV_REST_API_TOKEN) para ativar o registo de vendas.',
    });
  }

  const fmt = (o) => Object.fromEntries(
    Object.entries(o || {}).map(([k, v]) => [k, Math.round(parseFloat(v) * 100) / 100])
  );

  return res.status(200).json({
    enabled: true,
    vendas_por_conta: report.count,
    receita_por_conta: fmt(report.revenue),
    ultimas_vendas: report.recent,
  });
};
