/*
 * Cria um pagamento via Stripe (MB WAY ou Multibanco) — checkout transparente.
 * Gateway único. Chamado pelo frontend (checkout/upsells).
 */

const stripe = require('./_stripe');
const store = require('./_store');

function bad(res, status, error) { return res.status(status).json({ success: false, error }); }

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return bad(res, 405, 'Método não permitido');
  }

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
  if (!body || typeof body !== 'object') return bad(res, 400, 'JSON inválido');

  // amount em cêntimos (MB WAY: mín. €0,50).
  const amountCents = parseInt(body.amount, 10) || 0;
  if (amountCents < 50) return bad(res, 400, 'Valor inválido (mínimo €0,50)');

  const name = String(body.payerName || body.name || '').trim();
  const email = String(body.email || '').trim();
  const document = String(body.document || body.nif || '').replace(/\D+/g, '');
  const product = String(body.productName || 'Encomenda').trim().slice(0, 60);
  const method = (body.method === 'multibanco' ? 'multibanco' : 'mbway');

  let phoneDigits = String(body.phone || '').replace(/\D+/g, '');
  if (phoneDigits.startsWith('351') && phoneDigits.length === 12) phoneDigits = phoneDigits.slice(3);
  const phone = phoneDigits ? '+351' + phoneDigits : '';

  if (!name) return bad(res, 400, 'Nome obrigatório');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return bad(res, 400, 'E-mail inválido');
  if (method === 'mbway' && phoneDigits.length !== 9) return bad(res, 400, 'Telemóvel inválido (9 dígitos)');

  const isTest = body.test === true || body.test === '1' || req.headers['x-test-mode'] === '1';

  const metadata = {
    product, document, phone,
    payer_name: name, payer_email: email,
    test: String(isTest),
  };

  let r;
  if (method === 'multibanco') r = await stripe.createMultibanco({ amount: amountCents, name, email, metadata });
  else r = await stripe.createMbway({ amount: amountCents, phone, name, email, metadata });

  if (!r.ok || !r.data || r.data.error) {
    const msg = (r.data && r.data.error && r.data.error.message) || 'Falha ao comunicar com o gateway';
    console.error('[stripe:create] erro status=' + r.status + ' msg=' + msg);
    return bad(res, 502, msg);
  }

  const pi = r.data;
  const transactionId = pi.id;
  console.log('[stripe:create] ok method=' + method + ' test=' + isTest + ' pi=' + transactionId + ' status=' + pi.status);

  if (!isTest) {
    try {
      await store.saveTxOrigin(transactionId, {
        conta: 'stripe', value: amountCents / 100, method, gateway: 'stripe',
      });
    } catch (e) { console.error('[stripe:create] saveTxOrigin', e && e.message); }
  }

  const out = {
    success: true,
    transactionId,
    method,
    amount: amountCents / 100,
    currency: 'EUR',
    status: 'PENDING',
  };
  if (method === 'mbway') {
    out.mbwayPushed = pi.status === 'requires_action' || pi.status === 'processing';
    out.phone = phone;
  }
  if (method === 'multibanco' && pi.next_action && pi.next_action.multibanco_display_details) {
    const mb = pi.next_action.multibanco_display_details;
    out.entity = String(mb.entity || '');
    out.reference = String(mb.reference || '');
    out.expiresAt = mb.expires_at || null;
  }
  return res.status(200).json(out);
};
