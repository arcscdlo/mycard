/*
 * Store de vendas no Supabase (Postgres via PostgREST REST API — sem dependências).
 *
 * Grava cada compra com a sua origem (conta WayMB, gclid, ios) para termos
 * números persistentes (os logs do Vercel só retêm ~1 dia).
 *
 * Tabela public.vendas (já criada). Fluxo:
 *   - criação    → insere linha status=PENDING com a origem (não sobrescreve)
 *   - pagamento  → upsert status=PAID + dados do pagador (merge na mesma linha)
 *
 * Env: SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY. Sem elas, faz fallback (só loga).
 */

const BASE = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '').replace(/\/$/, '');
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY || '';
const ENABLED = !!(BASE && KEY);
const REST = BASE + '/rest/v1/vendas';

function headers(extra) {
  return Object.assign({
    apikey: KEY,
    Authorization: 'Bearer ' + KEY,
    'Content-Type': 'application/json',
  }, extra || {});
}

async function fetchT(url, opt, ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try { return await fetch(url, { ...opt, signal: c.signal }); }
  finally { clearTimeout(t); }
}

// Insere a origem da transação na criação (não sobrescreve se já existir).
async function saveTxOrigin(id, data) {
  if (!ENABLED || !id) return;
  try {
    await fetchT(REST + '?on_conflict=transaction_id', {
      method: 'POST',
      headers: headers({ Prefer: 'resolution=ignore-duplicates,return=minimal' }),
      body: JSON.stringify({
        transaction_id: id,
        conta: data.conta,
        gclid: !!data.gclid,
        ios_host: !!data.iosHost,
        value: data.value,
        method: data.method,
        gateway: data.gateway || 'stripe',
        status: 'PENDING',
      }),
    }, 4000);
  } catch (e) { console.error('[store] saveTxOrigin', e && e.message); }
}

async function getTxOrigin(id) {
  if (!ENABLED || !id) return null;
  try {
    const r = await fetchT(REST + '?transaction_id=eq.' + encodeURIComponent(id) + '&select=conta,gclid,ios_host,method', { headers: headers() }, 4000);
    const arr = await r.json().catch(() => null);
    return Array.isArray(arr) && arr[0] ? arr[0] : null;
  } catch (e) { return null; }
}

// Marca a venda como PAID (upsert merge — idempotente via unique transaction_id).
async function recordSale(sale) {
  if (!ENABLED) { console.log('[venda]', JSON.stringify(sale)); return false; }
  try {
    const row = {
      transaction_id: sale.transactionId,
      value: sale.value,
      currency: sale.currency || 'EUR',
      status: 'PAID',
      payer_name: sale.payer_name || null,
      payer_email: sale.payer_email || null,
      payer_document: sale.payer_document || null,
      source: sale.source || null,
      paid_at: sale.paidAt || new Date().toISOString(),
    };
    // Só inclui origem se conhecida (senão preserva a da criação no merge).
    if (sale.conta) row.conta = sale.conta;
    if (sale.method) row.method = sale.method;
    if (typeof sale.gclid === 'boolean') row.gclid = sale.gclid;
    if (typeof sale.iosHost === 'boolean') row.ios_host = sale.iosHost;

    await fetchT(REST + '?on_conflict=transaction_id', {
      method: 'POST',
      headers: headers({ Prefer: 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(row),
    }, 5000);
    console.log('[venda] gravada conta=' + (sale.conta || '?') + ' valor=' + sale.value + ' tx=' + sale.transactionId);
    return true;
  } catch (e) { console.error('[store] recordSale', e && e.message); return false; }
}

// Relatório agregado (vendas pagas) + últimas vendas.
async function getReport(n) {
  if (!ENABLED) return { enabled: false };
  try {
    const url = REST + '?status=eq.PAID'
      + '&select=transaction_id,conta,gclid,ios_host,value,currency,method,payer_name,payer_email,payer_document,source,paid_at'
      + '&order=paid_at.desc&limit=1000';
    const r = await fetchT(url, { headers: headers() }, 6000);
    const rows = await r.json().catch(() => []);
    const count = {}, revenue = {};
    let total = 0, totalRev = 0;
    for (const row of (Array.isArray(rows) ? rows : [])) {
      const c = row.conta || 'desconhecida';
      const v = parseFloat(row.value) || 0;
      count[c] = (count[c] || 0) + 1;
      revenue[c] = Math.round(((revenue[c] || 0) + v) * 100) / 100;
      total++; totalRev += v;
    }
    count._total = total;
    revenue._total = Math.round(totalRev * 100) / 100;
    return { enabled: true, count, revenue, recent: (Array.isArray(rows) ? rows : []).slice(0, n || 30) };
  } catch (e) { return { enabled: true, error: e && e.message }; }
}

module.exports = { ENABLED, saveTxOrigin, getTxOrigin, recordSale, getReport };
