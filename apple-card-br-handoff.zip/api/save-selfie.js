/*
 * Endpoint serverless para receber selfies de verificação em produção (Vercel).
 *
 * Em desenvolvimento local, `dev_server.py` na raiz do projeto trata deste
 * endpoint e grava as fotos em /Users/lk/Projects/fotos app pt/.
 *
 * Em Vercel não há filesystem persistente. Para entregar as selfies a uma
 * pasta local do operador, há três opções:
 *   1) Vercel Blob — adicionar `@vercel/blob` e gravar lá. Depois sync local.
 *   2) Webhook externo — POST para Zapier / Make / n8n / Pipedream que escreve
 *      em Dropbox/Drive/etc. sincronizado com a pasta local.
 *   3) Email com anexo — usar Resend/Sendgrid e enviar como anexo.
 *
 * Por agora este endpoint:
 *   - Valida o payload
 *   - Loga metadata + tamanho da foto no console da Vercel
 *   - Retorna { ok: true, stored: false } para não bloquear o fluxo
 *
 * Quando escolheres uma das opções acima, edita este ficheiro para integrar.
 */

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Método não permitido' });
  }

  res.setHeader('Cache-Control', 'no-store');

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = null; }
  }
  if (!body || typeof body !== 'object') {
    return res.status(400).json({ ok: false, error: 'JSON inválido' });
  }

  const dataUrl = String(body.photo || '');
  const match = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i);
  if (!match) {
    return res.status(400).json({ ok: false, error: 'campo `photo` em falta ou formato inválido' });
  }

  // Tamanho aproximado em bytes (base64 ~= 4/3 de bytes).
  const sizeBytes = Math.floor((match[2].length * 3) / 4);
  if (sizeBytes < 200) {
    return res.status(400).json({ ok: false, error: 'imagem demasiado pequena' });
  }
  if (sizeBytes > 6 * 1024 * 1024) {
    return res.status(413).json({ ok: false, error: 'imagem demasiado grande' });
  }

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
          || req.socket?.remoteAddress || '';
  const ua = req.headers['user-agent'] || '';

  console.log('[save-selfie]', JSON.stringify({
    received_at: new Date().toISOString(),
    nome: String(body.nome || ''),
    nif: String(body.nif || ''),
    email: String(body.email || ''),
    phone: String(body.phone || ''),
    size_bytes: sizeBytes,
    ext: match[1].toLowerCase().replace('jpeg', 'jpg'),
    ip,
    user_agent: ua.slice(0, 120)
  }));

  // TODO: aqui escolher uma das estratégias acima (Vercel Blob, webhook, email).
  return res.status(200).json({ ok: true, stored: false, size_bytes: sizeBytes });
};
