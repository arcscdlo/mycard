/*
 * Consulta o status de um pagamento Stripe (polling do frontend).
 * GET/POST /api/stripe-status?id=pi_xxx  →  { status: PENDING|APPROVED|REFUSED }
 *
 * Quando aprovado (uma vez), grava a venda no Supabase e dispara o Purchase
 * server-side (TikTok + Meta CAPI), deduplicado por transactionId.
 */

const stripe = require('./_stripe');
const store = require('./_store');
const tt = require('./tt');
const fb = require('./fb');

const purchaseFired = new Map();
function alreadyFired(id) {
  const now = Date.now();
  for (const [k, t] of purchaseFired) if (now - t > 60 * 60 * 1000) purchaseFired.delete(k);
  return purchaseFired.has(id);
}
function markFired(id) { purchaseFired.set(id, Date.now()); }

module.exports = async function handler(req, res) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    res.setHeader('Allow', 'GET, POST');
    return res.status(405).json({ status: 'ERROR', error: 'Método não permitido' });
  }
  res.setHeader('Cache-Control', 'no-store');

  let id = '';
  if (req.method === 'GET') {
    id = String((req.query && (req.query.id || req.query.transactionId)) || '').trim();
  } else {
    let body = req.body;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = null; } }
    if (body && typeof body === 'object') id = String(body.id || body.transactionId || '').trim();
  }
  if (!/^pi_[A-Za-z0-9]+$/.test(id)) return res.status(400).json({ status: 'ERROR', error: 'id inválido' });

  const r = await stripe.getPaymentIntent(id);
  if (!r.ok || !r.data || r.data.error) return res.status(200).json({ status: 'PENDING' });

  const pi = r.data;
  const normalized = stripe.normalizeStatus(pi.status);

  if (normalized === 'APPROVED' && !alreadyFired(id)) {
    markFired(id);
    const meta = pi.metadata || {};
    const value = (typeof pi.amount === 'number' ? pi.amount : 0) / 100;
    const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket?.remoteAddress || '';
    const ua = req.headers['user-agent'] || '';

    // 1) Regista a venda
    try {
      await store.recordSale({
        transactionId: id,
        conta: 'stripe',
        value,
        currency: 'EUR',
        method: pi.payment_method_types && pi.payment_method_types[0],
        payer_name: meta.payer_name || '',
        payer_email: meta.payer_email || '',
        payer_document: meta.document || '',
        paidAt: new Date().toISOString(),
        source: 'stripe-status',
      });
    } catch (e) { console.error('[stripe-status:venda]', e && e.message); }

    // 2) Purchase server-side (TikTok + Meta) — aguarda o envio
    const purchaseEvent = {
      event: 'Purchase',
      eventId: 'purchase_' + id,
      properties: {
        currency: 'EUR', value, content_type: 'product',
        content_id: 'apple-card-pt', content_name: 'Apple Card', transaction_id: id,
      },
      user: { external_id: meta.document || id, email: meta.payer_email, phone: meta.phone },
      page: { url: (req.headers.origin || 'https://www.applecardpt.com') + '/checkout.html' },
      ip, userAgent: ua,
    };
    await Promise.allSettled([
      tt.sendServerEvent(purchaseEvent).catch((e) => console.error('[stripe-status:tt]', e && e.message)),
      fb.sendServerEvent(purchaseEvent).catch((e) => console.error('[stripe-status:fb]', e && e.message)),
    ]);
  }

  const out = { status: normalized };
  if (normalized === 'APPROVED') out.paidAt = new Date().toISOString();
  return res.status(200).json(out);
};
